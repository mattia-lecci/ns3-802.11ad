#!/bin/bash
# General template for running programs in DRMAA environments.
eval "$1"
